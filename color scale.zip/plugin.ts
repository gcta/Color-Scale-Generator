// Plugin Penpot: Scala cromatica + cerchio sorgente + marker

interface ColorStep {
  label: string;
  hex: string;
}

// Palette esempio blu (puoi adattare!)
const colorScale: ColorStep[] = [
  { label: "100", hex: "#E3F2FD" },
  { label: "200", hex: "#BBDEFB" },
  { label: "300", hex: "#90CAF9" },
  { label: "400", hex: "#64B5F6" },
  { label: "500", hex: "#42A5F5" },
  { label: "600", hex: "#2196F3" },
  { label: "700", hex: "#1E88E5" },
  { label: "800", hex: "#1976D2" },
  { label: "900", hex: "#1565C0" },
  { label: "1000", hex: "#0D47A1" },
  { label: "1100", hex: "#092A6A" },
  { label: "1200", hex: "#061A3A" },
  { label: "1300", hex: "#020A16" }
];

// Marker sotto i campioni (indice, testo, colore testo)
const markersPreset = [
  { i: 0, text: "16.16", white: false },
  { i: 6, text: "4.6", white: true },
  { i: 12, text: "16.16", white: true }
];

// Dimensioni
const SWATCH_W = 72;
const SWATCH_H = 160;
const FONT_SIZE = 14;
const LABEL_TOP = 12;
const BLOCK_BOTTOM = 18;
const BLOCK_SPACING = 3;
const DOT_SIZE = 16;

// Offset di partenza per la scala
const START_X = 100;
const START_Y = 300;

// Funzione di utilità per il colore testo
function isDark(hex: string): boolean {
  hex = hex.replace("#", "");
  const r = parseInt(hex.substring(0, 2), 16) / 255;
  const g = parseInt(hex.substring(2, 4), 16) / 255;
  const b = parseInt(hex.substring(4, 6), 16) / 255;
  const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  return lum < 0.5;
}

// Funzione principale
export default async function run(ctx: any) {
  // Marker mapping
  const markers: Record<number, { text: string; white: boolean }> = {};
  for (const m of markersPreset) markers[m.i] = { text: m.text, white: m.white };

  // Crea la scala cromatica
  const rectNodes = [];
  for (let i = 0; i < colorScale.length; i++) {
    const color = colorScale[i];
    const x = START_X + i * SWATCH_W;
    const y = START_Y;

    // Rettangolo colore
    const rect = await ctx.createRect({
      x,
      y,
      width: SWATCH_W,
      height: SWATCH_H,
      fill: color.hex,
      stroke: "none",
      cornerRadius: 0
    });

    // Etichetta sopra
    await ctx.createText({
      x,
      y: y + LABEL_TOP,
      width: SWATCH_W,
      height: FONT_SIZE + 4,
      text: color.label,
      fontSize: FONT_SIZE,
      fill: isDark(color.hex) ? "#FFFFFF" : "#111111",
      align: "center"
    });

    // Marker sotto (se presente)
    if (markers[i]) {
      // Testo marker
      await ctx.createText({
        x,
        y: y + SWATCH_H - BLOCK_BOTTOM - DOT_SIZE - FONT_SIZE * 2 - BLOCK_SPACING * 2,
        width: SWATCH_W,
        height: FONT_SIZE + 4,
        text: markers[i].text,
        fontSize: FONT_SIZE,
        fill: markers[i].white ? "#FFFFFF" : "#111111",
        align: "center"
      });

      // Freccia ↓
      await ctx.createText({
        x,
        y: y + SWATCH_H - BLOCK_BOTTOM - DOT_SIZE - FONT_SIZE - BLOCK_SPACING,
        width: SWATCH_W,
        height: FONT_SIZE + 4,
        text: "↓",
        fontSize: FONT_SIZE,
        fill: markers[i].white ? "#FFFFFF" : "#111111",
        align: "center"
      });

      // Cerchietto marker
      await ctx.createEllipse({
        x: x + SWATCH_W / 2 - DOT_SIZE / 2,
        y: y + SWATCH_H - BLOCK_BOTTOM - DOT_SIZE,
        width: DOT_SIZE,
        height: DOT_SIZE,
        fill: markers[i].white ? "#FFFFFF" : "#111111",
        stroke: "none"
      });
    }

    rectNodes.push(rect);
  }

  // Cerchio sorgente: largo come un campione, attaccato sopra
  const closestIdx = Math.floor(colorScale.length / 2); // puoi calcolare dinamicamente!
  const circleX = START_X + closestIdx * SWATCH_W;
  const circleY = START_Y - SWATCH_W;

  await ctx.createEllipse({
    x: circleX,
    y: circleY,
    width: SWATCH_W,
    height: SWATCH_W,
    fill: colorScale[closestIdx].hex,
    stroke: "none"
  });
}